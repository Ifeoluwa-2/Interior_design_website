import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'framer-motion';
import { 
  FiSearch, FiShoppingBag, FiHeart, FiMenu, FiX, 
  FiArrowRight, FiArrowLeft, FiPlus, FiMinus,
  FiSun, FiMoon
} from 'react-icons/fi';

interface Product {
  id: string;
  name: string;
  designer: string;
  price: number;
  originalPrice?: number;
  image: string;
  images: string[];
  category: string;
  material: string;
  dimensions: string;
  year: string;
  featured?: boolean;
  newArrival?: boolean;
}

const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Luna Lounge Chair',
    designer: 'Mario Bellini Atelier',
    price: 4250,
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?q=80&w=1200&auto=format&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1538688525198-9b88f6f53126?q=80&w=1200&auto=format&fit=crop',
    ],
    category: 'Seating',
    material: 'Travertine base, bouclé wool, brushed brass',
    dimensions: 'W 86 × D 92 × H 74 cm',
    year: '2024',
    featured: true,
    newArrival: true,
  },
  {
    id: '2',
    name: 'Obsidian Dining Table',
    designer: 'Atelier Noir',
    price: 8900,
    originalPrice: 10200,
    image: 'https://images.unsplash.com/photo-1617806118233-18e1de247200?q=80&w=1200&auto=format&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1617806118233-18e1de247200?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1499933374294-4584851497cc?q=80&w=1200&auto=format&fit=crop',
    ],
    category: 'Tables',
    material: 'Black Marquina marble, oxidised steel',
    dimensions: 'Ø 180 × H 74 cm',
    year: '2024',
    featured: true,
  },
  {
    id: '3',
    name: 'Kiso Floor Lamp',
    designer: 'Nao Tamura',
    price: 1850,
    image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?q=80&w=1200&auto=format&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?q=80&w=1200&auto=format&fit=crop',
    ],
    category: 'Lighting',
    material: 'Hand-spun aluminum, rice paper, travertine',
    dimensions: 'Ø 45 × H 168 cm',
    year: '2023',
    newArrival: true,
  },
  {
    id: '4',
    name: 'Arcadia Sofa',
    designer: 'Paolo Ferrari',
    price: 12400,
    image: 'https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?q=80&w=1200&auto=format&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1540574163026-643ea20ade25?q=80&w=1200&auto=format&fit=crop',
    ],
    category: 'Seating',
    material: 'Natural linen, down fill, solid oak frame',
    dimensions: 'W 298 × D 108 × H 78 cm',
    year: '2024',
    featured: true,
  },
  {
    id: '5',
    name: 'Tsubo Side Table',
    designer: 'Atelier Noir',
    price: 1200,
    image: 'https://images.unsplash.com/photo-1538688525198-9b88f6f53126?q=80&w=1200&auto=format&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1538688525198-9b88f6f53126?q=80&w=1200&auto=format&fit=crop',
    ],
    category: 'Tables',
    material: 'Smoked oak, honed travertine',
    dimensions: 'Ø 48 × H 52 cm',
    year: '2023',
    newArrival: true,
  },
  {
    id: '6',
    name: 'Silhouet Cabinet',
    designer: 'India Mahdavi',
    price: 6700,
    image: 'https://images.unsplash.com/photo-1595427231395-c8eadc99296c?q=80&w=1200&auto=format&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1595427231395-c8eadc99296c?q=80&w=1200&auto=format&fit=crop',
    ],
    category: 'Storage',
    material: 'Ebonised walnut, fluted glass, brass',
    dimensions: 'W 160 × D 45 × H 88 cm',
    year: '2024',
    featured: true,
  },
];

const COLLECTIONS = [
  { name: 'Essentials 01', pieces: 12, image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?q=80&w=1200&auto=format&fit=crop', year: '2024' },
  { name: 'Travertine Studies', pieces: 8, image: 'https://images.unsplash.com/photo-1600210492493-0946911123ea?q=80&w=1200&auto=format&fit=crop', year: '2023' },
  { name: 'Night Editions', pieces: 6, image: 'https://images.unsplash.com/photo-1517705008128-361805f42e86?q=80&w=1200&auto=format&fit=crop', year: '2024' },
];

type Page = 'home' | 'shop' | 'product' | 'collections' | 'about' | 'contact';

export default function App() {
  const [page, setPage] = useState<Page>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(PRODUCTS[0]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [wishlist, setWishlist] = useState<Set<string>>(new Set(['1', '4']));
  const [cart, setCart] = useState<{product: Product; qty: number}[]>([
    { product: PRODUCTS[0], qty: 1 },
  ]);
  const [darkMode, setDarkMode] = useState(true);
  const [searchOpen, setSearchOpen] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const heroY = useTransform(scrollYProgress, [0, 1], ['0%', '30%']);
  const heroScale = useTransform(scrollYProgress, [0, 1], [1, 1.05]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  useEffect(() => {
    document.documentElement.style.scrollBehavior = 'smooth';
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const toggleWishlist = (id: string) => {
    const newWishlist = new Set(wishlist);
    if (newWishlist.has(id)) newWishlist.delete(id);
    else newWishlist.add(id);
    setWishlist(newWishlist);
  };

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item => item.product.id === product.id ? { ...item, qty: item.qty + 1 } : item);
      }
      return [...prev, { product, qty: 1 }];
    });
    setCartOpen(true);
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.qty, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);

  const Nav = () => (
    <motion.nav 
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed top-0 left-0 right-0 z-50 backdrop-blur-2xl bg-[#0a0a0b]/70 border-b border-white/5"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 h-[72px] flex items-center justify-between">
        <div className="flex items-center gap-16">
          <button onClick={() => setPage('home')} className="group">
            <div className="font-serif text-[22px] leading-none tracking-[-0.02em] text-white font-light">
              ATELIER <span className="font-medium">NOIR</span>
            </div>
            <div className="text-[10px] tracking-[0.3em] text-zinc-500 mt-1 font-mono uppercase">MILANO • NEW YORK</div>
          </button>
          
          <div className="hidden lg:flex items-center gap-10 text-[13px] tracking-[0.14em] font-medium">
            {[
              { id: 'shop', label: 'SHOP' },
              { id: 'collections', label: 'COLLECTIONS' },
              { id: 'about', label: 'STUDIO' },
              { id: 'contact', label: 'CONTACT' },
            ].map(item => (
              <button
                key={item.id}
                onClick={() => setPage(item.id as Page)}
                className={`relative py-2 text-zinc-400 hover:text-white transition-colors uppercase ${
                  page === item.id ? 'text-white' : ''
                }`}
              >
                {item.label}
                {page === item.id && (
                  <motion.div layoutId="navActive" className="absolute -bottom-px left-0 right-0 h-px bg-white" />
                )}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-5">
          <button 
            onClick={() => setSearchOpen(!searchOpen)}
            className="hidden md:flex items-center gap-3 pl-4 pr-3 h-10 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all text-xs tracking-widest text-zinc-400 hover:text-white"
          >
            <FiSearch className="w-3.5 h-3.5" />
            <span className="font-mono uppercase">Search</span>
            <span className="ml-2 px-1.5 py-0.5 rounded bg-white/10 text-[10px] font-mono text-zinc-500">⌘K</span>
          </button>

          <button
            onClick={() => setDarkMode(!darkMode)}
            className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-zinc-400 hover:text-white hover:bg-white/10 transition-all"
          >
            {darkMode ? <FiSun className="w-4 h-4" /> : <FiMoon className="w-4 h-4" />}
          </button>

          <button className="relative w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-zinc-400 hover:text-white hover:bg-white/10 transition-all">
            <FiHeart className="w-4 h-4" />
            {wishlist.size > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#c9a86e] text-[10px] font-medium text-black flex items-center justify-center">
                {wishlist.size}
              </span>
            )}
          </button>

          <button 
            onClick={() => setCartOpen(true)}
            className="relative w-10 h-10 rounded-full bg-white text-black flex items-center justify-center hover:bg-zinc-200 transition-all"
          >
            <FiShoppingBag className="w-4 h-4" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#c9a86e] text-[10px] font-medium text-black flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>

          <button 
            onClick={() => setMobileMenuOpen(true)}
            className="lg:hidden w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-zinc-400"
          >
            <FiMenu className="w-4 h-4" />
          </button>
        </div>
      </div>

      <AnimatePresence>
        {searchOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="border-t border-white/5 bg-[#0a0a0b]/95 backdrop-blur-2xl"
          >
            <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-4">
              <div className="flex items-center gap-4 max-w-2xl">
                <FiSearch className="w-4 h-4 text-zinc-500" />
                <input
                  autoFocus
                  placeholder="Search chairs, tables, lighting, designers…"
                  className="flex-1 bg-transparent outline-none text-white placeholder-zinc-600 text-sm"
                />
                <span className="text-xs font-mono text-zinc-600">ESC to close</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );

  const HomePage = () => (
    <div className="bg-[#0a0a0b] text-white">
      {/* Hero */}
      <section ref={heroRef} className="relative h-[100svh] min-h-[720px] overflow-hidden">
        <motion.div style={{ y: heroY, scale: heroScale }} className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1618220179428-22790b461013?q=80&w=2400&auto=format&fit=crop" 
            alt="Luxury interior"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/60 to-[#0a0a0b]" />
          <div className="absolute inset-0 opacity-[0.03]" style={{
            backgroundImage: `repeating-linear-gradient(0deg, white 0px, white 1px, transparent 1px, transparent 4px)`
          }} />
        </motion.div>

        <motion.div style={{ opacity: heroOpacity }} className="relative z-10 h-full max-w-[1400px] mx-auto px-6 lg:px-10 flex flex-col justify-end pb-20 lg:pb-28">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="max-w-5xl"
          >
            <div className="inline-flex items-center gap-3 mb-8 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-md">
              <span className="w-1.5 h-1.5 rounded-full bg-[#c9a86e] animate-pulse" />
              <span className="text-[11px] tracking-[0.2em] font-mono text-zinc-300 uppercase">ESSENTIALS 01 — NOW AVAILABLE</span>
            </div>

            <h1 className="font-serif text-[clamp(48px,9vw,128px)] leading-[0.85] tracking-[-0.03em] font-light mb-10">
              Furniture as<br />
              <span className="font-medium italic">quiet architecture</span>
            </h1>

            <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-10 max-w-4xl">
              <p className="text-[17px] leading-relaxed text-zinc-300 font-light max-w-xl">
                We design permanent objects for impermanent lives. Milanese craftsmanship, 
                Japanese restraint, and a refusal to follow trends.
              </p>
              <div className="flex gap-4">
                <button 
                  onClick={() => setPage('shop')}
                  className="group h-14 px-8 rounded-full bg-white text-black font-medium text-[13px] tracking-[0.14em] uppercase flex items-center gap-3 hover:bg-zinc-200 transition-all"
                >
                  Explore collection
                  <FiArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </button>
                <button 
                  onClick={() => setPage('collections')}
                  className="h-14 px-8 rounded-full bg-white/5 border border-white/15 backdrop-blur-md font-medium text-[13px] tracking-[0.14em] uppercase text-white hover:bg-white/10 transition-all"
                >
                  View lookbook
                </button>
              </div>
            </div>
          </motion.div>

          <div className="absolute bottom-10 right-6 lg:right-10 hidden lg:flex items-center gap-8 text-[10px] tracking-[0.2em] font-mono text-zinc-500 uppercase">
            <span>MMXXIV</span>
            <span className="w-px h-8 bg-white/10" />
            <span>EST. MILANO 2018</span>
          </div>
        </motion.div>

        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#0a0a0b] to-transparent pointer-events-none" />
      </section>

      {/* Featured Collections */}
      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-24 lg:py-32">
        <div className="flex items-end justify-between mb-16 gap-8">
          <div>
            <div className="text-[11px] tracking-[0.2em] font-mono text-zinc-500 uppercase mb-6">Featured Collections</div>
            <h2 className="font-serif text-[56px] lg:text-7xl leading-[0.9] tracking-[-0.02em] font-light">
              Objects with<br />a longer present
            </h2>
          </div>
          <button onClick={() => setPage('collections')} className="hidden lg:flex items-center gap-3 text-[13px] tracking-[0.14em] uppercase text-zinc-400 hover:text-white transition-colors">
            All collections
            <FiArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid lg:grid-cols-3 gap-6 lg:gap-8">
          {COLLECTIONS.map((col, i) => (
            <motion.article
              key={col.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ delay: i * 0.1 }}
              className="group cursor-pointer"
              onClick={() => setPage('collections')}
            >
              <div className="relative aspect-[4/5] overflow-hidden rounded-[24px] bg-zinc-900 mb-6">
                <img src={col.image} alt={col.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute top-5 left-5 px-3 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-[10px] tracking-widest font-mono text-zinc-300 uppercase">
                  {col.year}
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-8">
                  <div className="text-[11px] tracking-[0.2em] font-mono text-zinc-400 uppercase mb-3">{col.pieces} pieces</div>
                  <h3 className="font-serif text-3xl font-light text-white">{col.name}</h3>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      {/* New Arrivals Slider */}
      <section className="border-y border-white/5 bg-[#0c0c0d]">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-24 lg:py-28">
          <div className="flex items-end justify-between mb-12">
            <div>
              <div className="text-[11px] tracking-[0.2em] font-mono text-zinc-500 uppercase mb-4">New Arrivals • Autumn 2024</div>
              <h2 className="font-serif text-5xl lg:text-6xl tracking-[-0.02em] font-light">Recently completed</h2>
            </div>
            <div className="hidden md:flex gap-2">
              <button className="w-11 h-11 rounded-full border border-white/10 flex items-center justify-center text-zinc-400 hover:border-white/20 hover:text-white transition-all">
                <FiArrowLeft className="w-4 h-4" />
              </button>
              <button className="w-11 h-11 rounded-full bg-white text-black flex items-center justify-center hover:bg-zinc-200 transition-all">
                <FiArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
            {PRODUCTS.filter(p => p.newArrival).slice(0, 3).map((product, i) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="group cursor-pointer"
                onClick={() => { setSelectedProduct(product); setPage('product'); }}
              >
                <div className="relative aspect-[4/5] rounded-[20px] overflow-hidden bg-zinc-900 mb-5">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                  <div className="absolute top-4 right-4 w-9 h-9 rounded-full bg-black/70 backdrop-blur-md border border-white/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <FiPlus className="w-4 h-4 text-white" />
                  </div>
                  <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                    <span className="px-3 py-1 rounded-full bg-[#c9a86e] text-black text-[10px] font-medium tracking-widest uppercase">New</span>
                    <button
                      onClick={(e) => { e.stopPropagation(); toggleWishlist(product.id); }}
                      className="w-9 h-9 rounded-full bg-black/70 backdrop-blur-md border border-white/10 flex items-center justify-center text-white hover:bg-black transition-colors"
                    >
                      <FiHeart className={`w-3.5 h-3.5 ${wishlist.has(product.id) ? 'fill-[#c9a86e] text-[#c9a86e]' : ''}`} />
                    </button>
                  </div>
                </div>
                <div className="px-1">
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <div>
                      <h3 className="font-serif text-[22px] leading-tight font-light text-white mb-1">{product.name}</h3>
                      <p className="text-xs text-zinc-500 font-mono">{product.designer}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-[15px] font-medium text-white">€{product.price.toLocaleString()}</div>
                    </div>
                  </div>
                  <p className="text-[11px] leading-relaxed text-zinc-500">{product.material}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Editorial */}
      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-24 lg:py-32">
        <div className="grid lg:grid-cols-12 gap-16 items-start">
          <div className="lg:col-span-5">
            <div className="sticky top-32">
              <div className="text-[11px] tracking-[0.2em] font-mono text-zinc-500 uppercase mb-8">Editorial • Journal 04</div>
              <h2 className="font-serif text-5xl lg:text-6xl leading-[0.9] tracking-[-0.02em] font-light mb-8">
                The patience<br />of making
              </h2>
              <p className="text-[15px] leading-relaxed text-zinc-400 font-light mb-8 max-w-md">
                Ninety-four days to source the travertine. Six full-scale mockups. 
                One joint, resolved at 2am. We publish the notes, not just the photographs.
              </p>
              <button className="text-[13px] tracking-[0.14em] uppercase text-zinc-300 hover:text-white flex items-center gap-3 group">
                Read the essay
                <FiArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
          <div className="lg:col-span-7 space-y-8">
            <div className="relative aspect-[16/10] rounded-[24px] overflow-hidden bg-zinc-900">
              <img 
                src="https://images.unsplash.com/photo-1600210491892-03d54c0aaf87?q=80&w=1600&auto=format&fit=crop" 
                alt="Workshop"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="grid md:grid-cols-2 gap-8 text-[13px] leading-relaxed text-zinc-400 font-light">
              <p>
                Every piece begins with a question of time. How will this feel in 
                ten years, not ten weeks? We work with workshops that still measure 
                in generations, not quarters.
              </p>
              <p>
                The Essentials collection is our answer: twelve permanent objects 
                designed to outlive their owners, finished by hand in Brianza.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Instagram Gallery */}
      <section className="border-t border-white/5 bg-[#0c0c0d] py-24">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="flex items-end justify-between mb-12">
            <div>
              <div className="text-[11px] tracking-[0.2em] font-mono text-zinc-500 uppercase mb-4">@ateliernoir • In situ</div>
              <h2 className="font-serif text-4xl lg:text-5xl font-light">Objects in rooms that live</h2>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {[
              'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?q=80&w=600&auto=format&fit=crop',
              'https://images.unsplash.com/photo-1600210491892-03d54c0aaf87?q=80&w=600&auto=format&fit=crop',
              'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?q=80&w=600&auto=format&fit=crop',
              'https://images.unsplash.com/photo-1517705008128-361805f42e86?q=80&w=600&auto=format&fit=crop',
              'https://images.unsplash.com/photo-1499933374294-4584851497cc?q=80&w=600&auto=format&fit=crop',
              'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=600&auto=format&fit=crop',
            ].map((img, i) => (
              <div key={i} className="aspect-square rounded-2xl overflow-hidden bg-zinc-900 group cursor-pointer">
                <img src={img} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-24 lg:py-32">
        <div className="max-w-3xl">
          <h2 className="font-serif text-5xl lg:text-6xl leading-[0.9] tracking-[-0.02em] font-light mb-8">
            Receive the journal,<br />not the noise
          </h2>
          <p className="text-[17px] leading-relaxed text-zinc-400 font-light mb-10 max-w-xl">
            Four emails per year. Essays on making, workshop visits, and first 
            access to limited editions. No sales, no urgency.
          </p>
          <div className="flex gap-3 max-w-md">
            <input 
              type="email" 
              placeholder="your@email.com"
              className="flex-1 h-14 px-6 rounded-full bg-white/5 border border-white/10 text-white placeholder-zinc-500 outline-none focus:border-white/20 focus:bg-white/10 transition-all"
            />
            <button className="h-14 px-8 rounded-full bg-white text-black font-medium text-[13px] tracking-[0.14em] uppercase hover:bg-zinc-200 transition-all">
              Join
            </button>
          </div>
          <p className="text-[10px] tracking-wide text-zinc-600 mt-4 font-mono uppercase">
            By joining, you agree to our quiet approach to email. Unsubscribe anytime.
          </p>
        </div>
      </section>
    </div>
  );

  const ShopPage = () => (
    <div className="bg-[#0a0a0b] text-white pt-32 min-h-screen">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-16">
        <div className="mb-16 max-w-3xl">
          <div className="text-[11px] tracking-[0.2em] font-mono text-zinc-500 uppercase mb-6">Shop • All Objects</div>
          <h1 className="font-serif text-6xl lg:text-8xl leading-[0.85] tracking-[-0.03em] font-light mb-8">
            Permanent<br />collection
          </h1>
          <p className="text-[17px] leading-relaxed text-zinc-400 font-light max-w-xl">
            Twelve collections, fifty-seven objects. Everything we make is made to order, 
            with a 10–14 week lead time. That is not a bug. It is the point.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 mb-12 py-6 border-y border-white/5">
          {['All', 'Seating', 'Tables', 'Storage', 'Lighting', 'New', 'Essentials 01'].map((f, i) => (
            <button
              key={f}
              className={`px-5 h-10 rounded-full text-xs tracking-[0.14em] uppercase font-medium transition-all ${
                i === 0 
                  ? 'bg-white text-black' 
                  : 'bg-white/5 border border-white/10 text-zinc-400 hover:bg-white/10 hover:text-white hover:border-white/20'
              }`}
            >
              {f}
            </button>
          ))}
          <div className="ml-auto hidden lg:flex items-center gap-4 text-xs text-zinc-500 font-mono">
            <span>57 objects</span>
            <span className="w-px h-4 bg-white/10" />
            <span>Sort: Newest</span>
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16">
          {PRODUCTS.map((product) => (
            <motion.article
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="group cursor-pointer"
              onClick={() => { setSelectedProduct(product); setPage('product'); }}
            >
              <div className="relative aspect-[4/5] rounded-[24px] overflow-hidden bg-zinc-900 mb-5">
                <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                {product.originalPrice && (
                  <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-[#c9a86e] text-black text-[10px] font-medium tracking-widest uppercase">
                    Archive pricing
                  </div>
                )}
                <div className="absolute inset-0 ring-1 ring-inset ring-white/5 rounded-[24px] pointer-events-none" />
                <button
                  onClick={(e) => { e.stopPropagation(); toggleWishlist(product.id); addToCart(product); }}
                  className="absolute bottom-4 right-4 w-11 h-11 rounded-full bg-white text-black flex items-center justify-center shadow-2xl opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all hover:bg-zinc-100"
                >
                  <FiPlus className="w-4 h-4" />
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); toggleWishlist(product.id); }}
                  className="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/70 backdrop-blur-md border border-white/10 flex items-center justify-center text-white hover:bg-black transition-colors"
                >
                  <FiHeart className={`w-4 h-4 ${wishlist.has(product.id) ? 'fill-[#c9a86e] text-[#c9a86e]' : ''}`} />
                </button>
              </div>

              <div className="px-1">
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div>
                    <h3 className="font-serif text-[26px] leading-tight font-light text-white mb-1">{product.name}</h3>
                    <p className="text-[11px] text-zinc-500 font-mono tracking-wide">{product.designer} • {product.year}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-[17px] font-medium text-white">€{product.price.toLocaleString()}</div>
                    {product.originalPrice && (
                      <div className="text-xs text-zinc-500 line-through">€{product.originalPrice.toLocaleString()}</div>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-3 text-[10px] tracking-wide text-zinc-500 font-mono uppercase">
                  <span>{product.category}</span>
                  <span className="w-1 h-1 rounded-full bg-zinc-700" />
                  <span>{product.material.split(',')[0]}</span>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </div>
  );

  const ProductPage = () => selectedProduct && (
    <div className="bg-[#0a0a0b] text-white pt-32 min-h-screen">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-12">
        <button onClick={() => setPage('shop')} className="flex items-center gap-2 text-xs tracking-[0.14em] uppercase text-zinc-500 hover:text-white mb-12 transition-colors">
          <FiArrowLeft className="w-3 h-3" /> Back to collection
        </button>

        <div className="grid lg:grid-cols-12 gap-16 items-start">
          <div className="lg:col-span-7">
            <div className="relative aspect-[4/5] rounded-[24px] overflow-hidden bg-zinc-900 mb-6">
              <img src={selectedProduct.image} alt={selectedProduct.name} className="w-full h-full object-cover" />
            </div>
            <div className="grid grid-cols-3 gap-4">
              {selectedProduct.images.slice(0, 3).map((img, i) => (
                <div key={i} className="aspect-square rounded-2xl overflow-hidden bg-zinc-900">
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5 lg:sticky lg:top-32">
            <div className="text-[11px] tracking-[0.2em] font-mono text-zinc-500 uppercase mb-6">
              {selectedProduct.category} • {selectedProduct.year}
            </div>
            
            <h1 className="font-serif text-5xl lg:text-6xl leading-[0.9] tracking-[-0.02em] font-light mb-4">
              {selectedProduct.name}
            </h1>
            
            <p className="text-zinc-400 mb-8 font-mono text-sm">{selectedProduct.designer}</p>

            <div className="flex items-baseline gap-4 mb-10">
              <div className="text-3xl font-light">€{selectedProduct.price.toLocaleString()}</div>
              {selectedProduct.originalPrice && (
                <div className="text-lg text-zinc-500 line-through">€{selectedProduct.originalPrice.toLocaleString()}</div>
              )}
              <div className="ml-auto text-[10px] tracking-widest font-mono text-zinc-500 uppercase">Made to order • 10–14 weeks</div>
            </div>

            <div className="space-y-6 py-8 border-y border-white/10 mb-8 text-sm">
              <div className="grid grid-cols-3 gap-4">
                <div className="text-zinc-500 font-mono text-xs uppercase tracking-wide">Materials</div>
                <div className="col-span-2 text-zinc-200 leading-relaxed">{selectedProduct.material}</div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-zinc-500 font-mono text-xs uppercase tracking-wide">Dimensions</div>
                <div className="col-span-2 text-zinc-200 font-mono text-sm">{selectedProduct.dimensions}</div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-zinc-500 font-mono text-xs uppercase tracking-wide">Notes</div>
                <div className="col-span-2 text-zinc-400 leading-relaxed font-light">
                  Hand-finished in Brianza. Each piece is unique. Travertine varies naturally. 
                  Brass will patinate. This is intended.
                </div>
              </div>
            </div>

            <div className="flex gap-3 mb-12">
              <button 
                onClick={() => addToCart(selectedProduct)}
                className="flex-1 h-14 rounded-full bg-white text-black font-medium text-[13px] tracking-[0.14em] uppercase hover:bg-zinc-200 transition-all"
              >
                Add to order — €{selectedProduct.price.toLocaleString()}
              </button>
              <button
                onClick={() => toggleWishlist(selectedProduct.id)}
                className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-white/10 transition-all"
              >
                <FiHeart className={`w-5 h-5 ${wishlist.has(selectedProduct.id) ? 'fill-[#c9a86e] text-[#c9a86e]' : ''}`} />
              </button>
            </div>

            <div className="text-xs leading-relaxed text-zinc-500 font-light space-y-3">
              <p>• Free white-glove delivery in EU & UK. Worldwide shipping quoted.</p>
              <p>• 30-year structural warranty. We repair, we don’t replace.</p>
              <p>• Studio visits by appointment in Milano and New York.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#0a0a0b] text-white" style={{ fontFamily: 'Inter, system-ui, sans-serif' }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap');
        * { font-variant-numeric: oldstyle-nums; }
        .font-serif { font-family: 'Cormorant Garamond', Georgia, serif; }
        .font-mono { font-family: 'IBM Plex Mono', monospace; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #0a0a0b; }
        ::-webkit-scrollbar-thumb { background: #27272a; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #3f3f46; }
      `}</style>

      <Nav />

      <AnimatePresence mode="wait">
        <motion.main
          key={page}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        >
          {page === 'home' && <HomePage />}
          {page === 'shop' && <ShopPage />}
          {page === 'product' && <ProductPage />}
          {page === 'collections' && <ShopPage />}
          {page === 'about' && (
            <div className="bg-[#0a0a0b] text-white pt-32 min-h-screen">
              <div className="max-w-[1000px] mx-auto px-6 lg:px-10 py-24">
                <h1 className="font-serif text-6xl lg:text-8xl leading-[0.85] tracking-[-0.03em] font-light mb-12">
                  Studio<br />practice
                </h1>
                <div className="prose prose-invert max-w-none text-zinc-300 font-light leading-relaxed text-[18px] space-y-6">
                  <p>Atelier Noir was founded in Milan in 2018 by architect Elena Rossi and industrial designer Markus Weber. We met restoring a 1950s apartment in Brera and realized we shared a dislike for most contemporary furniture.</p>
                  <p>Too loud, too trend-aware, too eager to be photographed. We wanted objects that were quiet enough to live with for decades. Objects that improve with use, not obsolescence.</p>
                </div>
              </div>
            </div>
          )}
          {page === 'contact' && (
            <div className="bg-[#0a0a0b] text-white pt-32 min-h-screen">
              <div className="max-w-[1000px] mx-auto px-6 lg:px-10 py-24">
                <h1 className="font-serif text-6xl lg:text-8xl leading-[0.85] tracking-[-0.03em] font-light mb-16">
                  Visit the<br />studio
                </h1>
                <div className="grid md:grid-cols-2 gap-16 text-sm">
                  <div>
                    <div className="text-xs tracking-widest font-mono text-zinc-500 uppercase mb-4">Milano</div>
                    <p className="text-zinc-300 leading-relaxed font-light">Via Solferino 11<br />20121 Milano, IT<br /><br />Tuesday–Saturday, 10–18<br />Appointments preferred</p>
                  </div>
                  <div>
                    <div className="text-xs tracking-widest font-mono text-zinc-500 uppercase mb-4">New York</div>
                    <p className="text-zinc-300 leading-relaxed font-light">371 Broadway, 3rd Floor<br />New York, NY 10013<br /><br />Wednesday–Saturday, 11–19<br />By appointment only</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </motion.main>
      </AnimatePresence>

      {/* Cart Sidebar */}
      <AnimatePresence>
        {cartOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
              onClick={() => setCartOpen(false)}
            />
            <motion.aside
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="fixed right-0 top-0 h-full w-full max-w-md bg-[#0c0c0d] border-l border-white/10 z-50 flex flex-col"
            >
              <div className="p-8 border-b border-white/10">
                <div className="flex items-center justify-between">
                  <h2 className="font-serif text-2xl font-light">Order • {cartCount} items</h2>
                  <button onClick={() => setCartOpen(false)} className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10">
                    <FiX className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-8 space-y-6">
                {cart.map(item => (
                  <div key={item.product.id} className="flex gap-4">
                    <img src={item.product.image} alt="" className="w-20 h-24 object-cover rounded-xl bg-zinc-900" />
                    <div className="flex-1 min-w-0">
                      <h3 className="font-serif text-lg leading-tight font-light mb-1">{item.product.name}</h3>
                      <p className="text-xs text-zinc-500 font-mono mb-3">{item.product.designer}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <button className="w-7 h-7 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10">
                            <FiMinus className="w-3 h-3" />
                          </button>
                          <span className="w-8 text-center text-sm font-mono">{item.qty}</span>
                          <button className="w-7 h-7 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10">
                            <FiPlus className="w-3 h-3" />
                          </button>
                        </div>
                        <div className="text-sm font-medium">€{(item.product.price * item.qty).toLocaleString()}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-8 border-t border-white/10 bg-[#0a0a0b]">
                <div className="space-y-3 mb-6 text-sm">
                  <div className="flex justify-between text-zinc-400">
                    <span>Subtotal</span>
                    <span className="font-mono">€{cartTotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-zinc-400">
                    <span>Delivery</span>
                    <span className="font-mono">Quoted</span>
                  </div>
                  <div className="flex justify-between text-lg font-medium pt-3 border-t border-white/10">
                    <span>Total</span>
                    <span className="font-mono">€{cartTotal.toLocaleString()}</span>
                  </div>
                </div>
                <button className="w-full h-12 rounded-full bg-white text-black font-medium text-xs tracking-[0.14em] uppercase hover:bg-zinc-200 transition-all">
                  Continue to inquiry
                </button>
                <p className="text-[10px] text-zinc-500 text-center mt-3 font-mono uppercase tracking-wide">
                  10–14 week lead time • White glove delivery
                </p>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-[#0a0a0b] z-50 lg:hidden"
          >
            <div className="p-6 flex items-center justify-between border-b border-white/5">
              <div className="font-serif text-xl tracking-[-0.02em]">ATELIER <span className="font-medium">NOIR</span></div>
              <button onClick={() => setMobileMenuOpen(false)} className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center">
                <FiX className="w-5 h-5" />
              </button>
            </div>
            <div className="p-8 space-y-8">
              {[
                { id: 'shop', label: 'Shop' },
                { id: 'collections', label: 'Collections' },
                { id: 'about', label: 'Studio' },
                { id: 'contact', label: 'Contact' },
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => { setPage(item.id as Page); setMobileMenuOpen(false); }}
                  className="block font-serif text-4xl font-light text-white"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="border-t border-white/5 bg-[#080808] text-zinc-400">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-16">
          <div className="grid lg:grid-cols-12 gap-12 mb-16">
            <div className="lg:col-span-5">
              <div className="font-serif text-2xl tracking-[-0.02em] text-white mb-4 font-light">
                ATELIER <span className="font-medium">NOIR</span>
              </div>
              <p className="text-sm leading-relaxed text-zinc-500 font-light max-w-md">
                Permanent objects for impermanent lives. Milanese craftsmanship, 
                Japanese restraint, made to order since 2018.
              </p>
            </div>
            <div className="lg:col-span-7 grid grid-cols-2 md:grid-cols-4 gap-8 text-xs">
              <div>
                <div className="font-mono uppercase tracking-widest text-zinc-500 mb-4">Shop</div>
                <div className="space-y-2 text-zinc-400">
                  <div>Seating</div>
                  <div>Tables</div>
                  <div>Lighting</div>
                  <div>Storage</div>
                </div>
              </div>
              <div>
                <div className="font-mono uppercase tracking-widest text-zinc-500 mb-4">Studio</div>
                <div className="space-y-2 text-zinc-400">
                  <div>About</div>
                  <div>Journal</div>
                  <div>Process</div>
                  <div>Press</div>
                </div>
              </div>
              <div>
                <div className="font-mono uppercase tracking-widest text-zinc-500 mb-4">Client</div>
                <div className="space-y-2 text-zinc-400">
                  <div>Contact</div>
                  <div>Delivery</div>
                  <div>Warranty</div>
                  <div>Trade</div>
                </div>
              </div>
              <div>
                <div className="font-mono uppercase tracking-widest text-zinc-500 mb-4">Follow</div>
                <div className="space-y-2 text-zinc-400">
                  <div>Instagram</div>
                  <div>Are.na</div>
                  <div>Journal</div>
                </div>
              </div>
            </div>
          </div>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pt-8 border-t border-white/5 text-[10px] font-mono tracking-wide text-zinc-600 uppercase">
            <div>© 2024 Atelier Noir SRL • Milano • VAT IT12345678901</div>
            <div className="flex items-center gap-6">
              <span>Privacy</span>
              <span>Terms</span>
              <span>Cookies</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}